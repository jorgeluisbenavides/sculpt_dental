<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('folio');
            $table->mediumtext('name');
            $table->mediumtext('last_name_one');
            $table->mediumtext('last_name_two');
            $table->text('address');
            $table->text('references');
            $table->date('age');
            $table->integer('cell_phone');
            $table->integer('home_phone');
            $table->enum('sex',['MALE','FEMALE'])->default('MALE'); //posibles valores, en 
            $table->enum('civil_state',['SINGLE','MARRIED','WIDOWER'])->default('SINGLE'); //posibles valores, en 
            $table->mediumtext('img_name');
            $table->integer('occupation_id')->unsigned();

            //Relaciones
            $table->foreign('occupation_id')->references('id')->on('occupations')
            ->onUpdate('cascade')
            ->onDelete('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
